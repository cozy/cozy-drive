



# Consultation  des fichiers `.md` et `.txt`

Consultez les contenus de vos fichiers `.md` et `.txt` directement dans votre Cozy!
Sur votre app mobile Cozy Drive, dans votre Cozy web, hébergé sur Cozy Cloud ou par vos soins.

## Facile à lire

Les formats et la syntaxe des fichiers en Markdown (`.md`) vous facilitent la lecture. L'édition en est très facile.

* Source Wikipedia : [https://en.wikipedia.org/wiki/Markdown](https://en.wikipedia.org/wiki/Markdown)
* Source Framasoft : [https://docs.framasoft.org/fr/grav/markdown.html](https://docs.framasoft.org/fr/grav/markdown.html)

## Partagez vos fichiers

Depuis votre Cozy, comme pour les autres documents, partagez vos fichiers `.md`ou `.txt`, les destinataires de ces partages verront en un clic le contenu des fichiers partagés.




```
               .=.,
              ;c =\
            __|  _/
          .'-'-._/-'-._
         /..   ____    \
        /' _  [<_->] )  \
       (  / \--\_>/-/'._ )
        \-;_/\__;__/ _/ _/
         '._}|==o==\{_\/
          /  /-._.--\  \_
         // /   /|   \ \ \
        / | |   | \;  |  \ \
       / /  | :/   \: \   \_\
      /  |  /.'|   /: |    \ \
      |  |  |--| . |--|     \_\
      / _/   \ | : | /___--._) \
     |_(---'-| >-'-| |       '-'
            /_/     \_\

```


Claude, Cozy Cloud
